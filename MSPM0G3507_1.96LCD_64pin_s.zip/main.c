#include "ti/driverlib/dl_gpio.h"
#include "ti/driverlib/m0p/dl_core.h"
#include "ti_msp_dl_config.h"
#include <stdio.h>

#include "delay.h"
#include "lcd_init.h"
#include "lcd.h"
#include "pic.h"

int main(void)
{
	SYSCFG_DL_init(); //SYSCFG初始化

    DL_GPIO_setPins(LED_PORT, LED_PIN_LED_PIN); //测试用LED
    printf("By EussGaler"); //串口输出测试
    LCD_Init(); //初始化LCD

    // LCD_Fill(0,0,LCD_W,LCD_H,RED);
    // delay_ms(1000);

    // LCD_Fill(0,0,LCD_W,LCD_H,GREEN);
    // delay_ms(1000);

    // LCD_Fill(0,0,LCD_W,LCD_H,BLUE);
    // delay_ms(1000);

    LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
    delay_ms(1000);

    // LCD_ShowString(10,33,(uint8_t *)"LCD_W:",RED,WHITE,32,0);
    // delay_ms(1000);

    // LCD_ShowIntNum(106,33,LCD_W,3,RED,WHITE,32);
    // delay_ms(1000);

    // LCD_ShowString(10,66,(uint8_t *)"LCD_H:",RED,WHITE,32,0);
    // delay_ms(1000);

    // LCD_ShowIntNum(106,66,LCD_H,3,RED,WHITE,32);
    // delay_ms(1000);

    // LCD_ShowFloatNum1(10,99,0.11,4,RED,WHITE,32);
    // delay_ms(1000);

    // LCD_ShowChinese(40, 0, (uint8_t *)"液晶屏", RED, WHITE, 12, 0);
    // delay_ms(1000);

    // LCD_ShowChinese(40, 20, (uint8_t *)"液晶屏", RED, WHITE, 16, 0);
    // delay_ms(1000);

    // LCD_ShowChinese(40, 40, (uint8_t *)"液晶屏", RED, WHITE, 24, 0);
    // delay_ms(1000);

    // LCD_ShowChinese(40, 80, (uint8_t *)"液晶屏", RED, WHITE, 32, 0);
    // delay_ms(1000);

    // LCD_ShowPicture(10, 40, 80, 75, Takuru_Logo);
    // delay_ms(1000);

    // LCD_ShowPicture(100, 40, 80, 79, HIT_Logo);
    // delay_ms(1000);

    // LCD_ShowPicture(100, 130, 120, 76, EIDC_Logo);
    // delay_ms(1000);

    LCD_ShowPicture(0, 0, 280, 191, Sanae_Pic2);
    LCD_ShowString(50, 200, (uint8_t *)"Kochiya Sanae", GREEN, WHITE, 32, 0);

    while(1)
    {
        
    }
}