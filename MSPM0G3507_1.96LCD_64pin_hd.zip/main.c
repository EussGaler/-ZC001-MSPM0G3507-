#include "ti/driverlib/dl_gpio.h"
#include "ti/driverlib/m0p/dl_core.h"
#include "ti_msp_dl_config.h"
#include <stdio.h>

#include "delay.h"
#include "lcd_init.h"
#include "lcd.h"
#include "pic.h"
#include "mydma.h"

uint8_t LCD_DataTransmit[2 * LCD_W]; //DMA传输数据

int main(void)
{
	SYSCFG_DL_init(); //SYSCFG初始化
    LCD_Init(); //初始化LCD
    SPI_DMA_Init(); //初始化SPI和DMA

    DL_GPIO_setPins(LED_PORT, LED_PIN_LED_PIN); //测试用LED
    printf("By EussGaler"); //串口输出测试

    while(1)
    {
        LCD_Fill(0, 0, LCD_W, LCD_H, BLUE);
        delay_ms(1000);
        LCD_Fill(0, 0, LCD_W, LCD_H, GREEN);
        delay_ms(1000);
        LCD_Fill(0, 0, LCD_W, LCD_H, RED);
        delay_ms(1000);
        LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
        delay_ms(1000);
        LCD_ShowPicture(0, 0, 280, 191, Sanae_Pic2);
        delay_ms(1000);
    }
}
