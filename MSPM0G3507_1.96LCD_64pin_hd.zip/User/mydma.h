#ifndef __MYDMA_H
#define __MYDMA_H

#include "ti_msp_dl_config.h"

void SPI_DMA_Init(void); //初始化SPI和DMA
void MyDMA_Start(void); //开启DMA写数据

#endif
