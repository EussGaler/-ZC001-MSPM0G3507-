#include "mydma.h"

#include "lcd_init.h"
#include "lcd.h"
#include "ti/devices/msp/peripherals/hw_flashctl.h"
#include "ti/driverlib/dl_dma.h"
#include "ti/driverlib/dl_spi.h"

extern uint8_t LCD_DataTransmit[2 * LCD_W]; //DMA传输数据
volatile bool Is_SPIData_Transmitted = false; //SPI数据是否传输至FIFO
volatile bool Is_DMATXData_Transferred = false; //DMA数据是否传输至SPI

//初始化SPI和DMA
void SPI_DMA_Init(void) 
{
    NVIC_EnableIRQ(SPI_LCD_INST_INT_IRQN); //使能中断
    DL_SPI_enableDMATransmitEvent(SPI_LCD_INST); //令SPI触发DMA。自动生成的代码里可能没有这句话！！
}

// 开启DMA写数据，类似LCD_Writ_Bus
void MyDMA_Start(void)
{
    LCD_CS_Clr();
    
    Is_SPIData_Transmitted = false;
    Is_DMATXData_Transferred = false;

    //每次使能前要重新配置DMA
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &LCD_DataTransmit[0]); //设置起始地址
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) (&SPI_LCD_INST->TXDATA)); //设置目标地址
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, sizeof(LCD_DataTransmit) / sizeof(LCD_DataTransmit[0])); //设置传输大小
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID); //使能DMA

    while (false == Is_DMATXData_Transferred);
    while (false == Is_SPIData_Transmitted);

    DL_DMA_disableChannel(DMA, DMA_CH0_CHAN_ID);

    LCD_CS_Set();
}

void SPI_LCD_INST_IRQHandler(void)
{
    switch (DL_SPI_getPendingInterrupt(SPI_LCD_INST))
    {
        case DL_SPI_IIDX_DMA_DONE_TX:
            Is_DMATXData_Transferred = true;
            break;
        case DL_SPI_IIDX_TX_EMPTY:
            Is_SPIData_Transmitted = true;
            break;
        default:
            break;
    }
}
