# **[ZC001]基于64pin_MSPM0G3507的1.69寸LCD驱动程序**

ZC001--自存001

---

## **1. 引脚定义**

### **1.1 spi TFT液晶LCD屏**

| IO口 | 用途 | 说明 |
| :--: | :--: | :--: |
| PB09 | SCL | GPIO |
| PB08 | SDA | GPIO |
| PB10 | RES | GPIO |
| PB11 | DC | GPIO |
| PB14 | CS | GPIO |
| PB26 | BLK | GPIO |

## **2.说明**

1. Sanae_Pic图片几乎占用了单片机FLASH全部128k，比较极限